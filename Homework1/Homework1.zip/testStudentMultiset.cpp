#include "StudentMultiset.h"
#include<iostream>
using namespace std;
int main()
{
	/*StudentMultiset ms;
	ms.add(123);
	ms.add(234);
	ms.print();
	StudentMultiset ms2=ms;
	cout<<ms.size();
	cout<<endl;
	ms2.add(15);
	cout<<endl;
	ms2.print();
	cout<<endl;
	ms.print();*/
}